#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb 25 17:52:39 2024

@author: apirodd
"""

import ldap

def ldap_search():
    ldap_server = "ldap.forumsys.com"
    ldap_conn = ldap.initialize("ldap://" + ldap_server)

    # Bind con l'utente e password specificati
    ldap_conn.simple_bind_s("uid=tesla,dc=example,dc=com", "password")

    # Definizione della base di ricerca
    base_dn = "dc=example,dc=com"

    # Creazione della query di ricerca
    search_filter = "(objectclass=*)"

    # Esecuzione della ricerca
    result = ldap_conn.search_s(base_dn, ldap.SCOPE_SUBTREE, search_filter)

    # Chiusura della connessione
    ldap_conn.unbind()

    return result

# Esempio di utilizzo
search_result = ldap_search()
for dn, entry in search_result:
    print("DN:", dn)
    print("Entry:", entry)
